import os
import tempfile
import unittest
from datetime import date
from pathlib import Path

from app import app, build_pool, init


class PoolLogicTests(unittest.TestCase):
    def setUp(self):
        self.rows = [
            {"id": 1, "name": "A", "village": "Partapur, Meerut", "crop": "Wheat", "qty": 20, "ready": "2026-12-02"},
            {"id": 2, "name": "B", "village": "Partapur, Meerut", "crop": "Wheat", "qty": 15, "ready": "2026-12-03"},
            {"id": 3, "name": "C", "village": "Mohkampur, Meerut", "crop": "Wheat", "qty": 25, "ready": "2026-12-04"},
            {"id": 4, "name": "D", "village": "Meerut", "crop": "Wheat", "qty": 40, "ready": "2026-12-15"},
        ]

    def test_quantity_proportional_cost_split(self):
        result = build_pool(self.rows[:3], 70, 3)
        self.assertEqual(result["total"], 60)
        self.assertEqual(sum(x["share"] for x in result["farmers"]), 7500)
        self.assertEqual(result["cost"], 7500)
        self.assertEqual(result["individual_cost"], 12000)
        self.assertEqual(result["saving"], 4500)

    def test_vehicle_capacity_is_respected(self):
        result = build_pool(self.rows[:3], 40, 3)
        self.assertLessEqual(result["total"], 40)

    def test_date_window_filters_farmer(self):
        result = build_pool(self.rows, 100, 3, "2026-12-02")
        self.assertNotIn("D", [x["name"] for x in result["farmers"]])

    def test_empty_rows(self):
        self.assertEqual(build_pool([], 70)["total"], 0)

    def test_invalid_capacity(self):
        with self.assertRaises(ValueError):
            build_pool(self.rows, 0)


class RouteTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        import app as app_module
        self.old_db = app_module.DB
        app_module.DB = Path(self.tmp.name) / "test.db"
        init()
        self.client = app.test_client()

    def tearDown(self):
        import app as app_module
        app_module.DB = self.old_db
        self.tmp.cleanup()

    def test_home_and_health(self):
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(self.client.get("/health").json["status"], "ok")

    def test_api_routes(self):
        for path in ["/api/summary", "/api/farmers", "/api/pooling", "/api/mandis", "/api/buyers"]:
            self.assertEqual(self.client.get(path).status_code, 200, path)

    def test_register_farmer(self):
        response = self.client.post("/api/farmers", json={
            "name": "Test Farmer", "phone": "9876543210", "village": "Test Village",
            "crop": "Wheat", "quantity": 12, "ready_date": "2026-12-10"
        })
        self.assertEqual(response.status_code, 201)
        self.assertEqual(len(self.client.get("/api/farmers").json), 6)

    def test_profit(self):
        response = self.client.post("/api/profit", json={
            "quantity": 10, "price": 2500, "transport": 100, "loading": 30, "fees": 20
        })
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json["net"], 23500)

    def test_pooled_transport_is_lower(self):
        individual = self.client.get("/api/mandis?crop=Wheat&pooled=false").json
        pooled = self.client.get("/api/mandis?crop=Wheat&pooled=true").json
        by_name = {x["name"]: x for x in pooled}
        for row in individual:
            self.assertLess(by_name[row["name"]]["transport"], row["transport"])


if __name__ == "__main__":
    unittest.main()
