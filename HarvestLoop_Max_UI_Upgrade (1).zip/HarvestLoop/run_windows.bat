@echo off
setlocal
cd /d "%~dp0"
echo.
echo  HARVESTLOOP - Smart Agricultural Logistics
echo  -----------------------------------------
where py >nul 2>nul
if %errorlevel%==0 (
  set "PY=py"
) else (
  set "PY=python"
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating virtual environment...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo ERROR: Python was not found or virtual environment creation failed.
    echo Install Python 3.10+ from https://www.python.org/downloads/windows/
    echo During installation, enable Add Python to PATH.
    pause
    exit /b 1
  )
)
echo Installing required packages...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo ERROR: Dependency installation failed.
  pause
  exit /b 1
)
echo Starting HarvestLoop...
".venv\Scripts\python.exe" app.py
pause
