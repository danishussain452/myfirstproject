# HARVESTLOOP — Hackathon-ready prototype
**Team Bugs Slayer · HACKNOVA 2026 · Track 3: Agriculture & Rural Livelihoods**

> Every harvest deserves the best possible return.

HarvestLoop is a farmer-first agricultural logistics prototype. It demonstrates farmer harvest registration, explainable crop/date/capacity-based load pooling, illustrative transport-cost sharing, mandi comparison by estimated net return, a sample buyer directory and a profit calculator.

## Run on Windows
1. Install Python 3.10 or newer from https://www.python.org/downloads/windows/.
2. Extract this ZIP.
3. Open the `HarvestLoop_Hackathon_Ready` folder.
4. Double-click `run_windows.bat`.

Or run manually in PowerShell:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Run tests
```powershell
python -m unittest discover -s tests -v
```

## Features
- Farmer registration and directory backed by SQLite.
- Smart load pooling demo: same crop, compatible harvest-date window and vehicle capacity.
- Quantity-proportional shared transport cost allocation.
- Transparent comparison of illustrative separate-trip and shared-trip estimates.
- Mandi comparison ranked by estimated net return after transport, loading and fees.
- Toggle between individual and pooled transport assumptions.
- Crop quantity chart rendered with dependency-free SVG.
- Illustrative buyer directory and net-profit calculator.
- Responsive desktop/tablet/mobile layout.

## Matching algorithm
The pooling routine is intentionally explainable:
1. Select farmer records for the chosen crop.
2. Ignore invalid harvest dates and non-positive quantities.
3. Apply an optional anchor date and configurable day window.
4. Sort by harvest date, locality text and record ID.
5. Add records while vehicle capacity is not exceeded.
6. Allocate shared trip estimate in proportion to each farmer's quantity.

Location compatibility is only a text-based regional hint. The prototype does **not** have GPS coordinates, road routing, verified proximity, live truck availability or route optimization.

## Important demo and data disclosure
All seeded farmer records, mandi prices, buyer profiles, distances, loading/fee values and transport-cost assumptions are sample data. They are not live Agmarknet/e-NAM prices, verified transport quotes, real buyer commitments or confirmed market availability.

For the load-pooling demonstration, the illustrative assumptions are ₹4,000 per separate trip and ₹7,500 for a shared group trip. Mandi transport estimates use illustrative per-km rates (₹5 individual / ₹3 pooled). Replace these assumptions with real local quotes and validated operating data before real-world use.

## API endpoints
- `GET /api/summary`
- `GET, POST /api/farmers`
- `GET /api/pooling?crop=Wheat&capacity=70&window=3`
- `GET /api/mandis?crop=Wheat&quantity=20&pooled=true`
- `GET /api/buyers?crop=Wheat`
- `POST /api/profit`
- `GET /health`

## Suggested 2-minute demo
1. Open Overview and explain the farmer-first workflow.
2. Register a new wheat harvest with a future ready date.
3. Open Smart Load Pooling, select Wheat and a vehicle capacity, and show matched farmers, utilization and cost allocation.
4. Open Mandi Comparison and toggle pooled transport to show how estimated transport changes net returns.
5. Open Buyer Network and Profit Calculator.
6. Explicitly state which data is illustrative and what would be integrated next (live mandi data, GPS/routing, verified transporters and buyer onboarding).

## Roadmap
- Integrate verified live mandi price feeds where access and terms permit.
- Add GPS-based proximity and route distance using a mapping provider.
- Add real transporter quotations and vehicle availability.
- Add farmer verification, consent, privacy controls and secure authentication.
- Add multilingual UI and low-bandwidth/offline-first support.
