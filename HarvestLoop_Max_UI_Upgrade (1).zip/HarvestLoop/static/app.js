const $ = id => document.getElementById(id);
const cash = n => "₹" + Number(n || 0).toLocaleString("en-IN", {maximumFractionDigits: 0});
async function api(url, options) {
  const response = await fetch(url, options);
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Request failed. Please try again.");
  return data;
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
}
function page(id) {
  document.querySelectorAll(".page").forEach(el => el.classList.toggle("hidden", el.id !== id));
  document.querySelectorAll("nav button").forEach(el => el.classList.toggle("active", el.dataset.page === id));
  const headings = {home:"Every harvest deserves a better return.",register:"Register your harvest",pool:"Smart load pooling",markets:"Mandi comparison",buyers:"Buyer network",calc:"Net profit calculator"};
  $("heading").textContent = headings[id] || headings.home;
  $("sidebar").classList.remove("open"); $("scrim").classList.remove("show");
  if (id === "register") loadFarmers();
  if (id === "pool") pool();
  if (id === "markets") markets();
  if (id === "buyers") buyers();
}
document.querySelectorAll("nav button").forEach(button => button.addEventListener("click", () => page(button.dataset.page)));
$("menuBtn").addEventListener("click", () => {$("sidebar").classList.toggle("open");$("scrim").classList.toggle("show");});
$("scrim").addEventListener("click", () => {$("sidebar").classList.remove("open");$("scrim").classList.remove("show");});
function table(rows) { return `<table><tbody>${rows}</tbody></table>`; }
function cropDonut(crops) {
  const total = crops.reduce((s, x) => s + Number(x.quantity), 0);
  if (!total) return "<p class='footnote'>No registered crop quantities yet.</p>";
  const colors = ["#1c5943", "#d9b96e", "#8aaf91", "#a9b8a2"];
  let offset = 0;
  const arcs = crops.map((crop, i) => {
    const pct = Number(crop.quantity) / total * 100;
    const dash = `${pct} ${100-pct}`;
    const circle = `<circle r="39" cx="50" cy="50" fill="none" stroke="${colors[i%colors.length]}" stroke-width="13" stroke-dasharray="${dash}" stroke-dashoffset="${-offset}" pathLength="100"/>`;
    offset += pct; return circle;
  }).join("");
  const legend = crops.map((x,i)=>`<div style="display:flex;align-items:center;gap:7px;font-size:10px;margin:7px 0"><i style="width:8px;height:8px;border-radius:50%;background:${colors[i%colors.length]}"></i>${escapeHTML(x.crop)} <b style="margin-left:auto">${Number(x.quantity).toLocaleString("en-IN")} qtl</b></div>`).join("");
  return `<div style="display:flex;align-items:center;gap:24px;flex-wrap:wrap"><svg viewBox="0 0 100 100" width="145" role="img" aria-label="Crop quantity distribution">${arcs}<text x="50" y="48" text-anchor="middle" font-size="10" fill="#123d30" font-weight="700">${total}</text><text x="50" y="59" text-anchor="middle" font-size="5" fill="#7c8980">QUINTALS</text></svg><div style="min-width:130px;flex:1">${legend}</div></div>`;
}
async function summary() {
  const data = await api("/api/summary");
  $("count").textContent = data.farmers;
  $("qty").textContent = `${Number(data.quantity).toLocaleString("en-IN")} qtl`;
  $("marketCount").textContent = data.mandis;
  $("cropChart").innerHTML = cropDonut(data.crops || []);
}
async function loadFarmers() {
  const list = await api("/api/farmers");
  $("farmers").innerHTML = list.length ? table(`<tr><th>Farmer</th><th>Village</th><th>Crop</th><th>Quantity</th><th>Ready date</th></tr>` + list.map(f=>`<tr><td>${escapeHTML(f.name)}</td><td>${escapeHTML(f.village)}</td><td>${escapeHTML(f.crop)}</td><td>${f.qty} qtl</td><td>${escapeHTML(f.ready)}</td></tr>`).join("")) : "<p class='footnote'>No farmers registered yet.</p>";
}
$("farmerForm").addEventListener("submit", async event => {
  event.preventDefault(); const form = event.currentTarget; const data = Object.fromEntries(new FormData(form));
  try {
    const result = await api("/api/farmers", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    $("msg").textContent = result.message; form.reset(); await loadFarmers(); await summary();
  } catch (error) {$("msg").textContent = error.message;}
});
async function pool() {
  try {
    const url = `/api/pooling?crop=${encodeURIComponent($("pcrop").value)}&capacity=${encodeURIComponent($("capacity").value)}&window=${encodeURIComponent($("window").value)}`;
    const data = await api(url);
    $("ptotal").textContent = `${data.total} qtl`; $("putil").textContent = `${data.util}%`;
    $("pcost").textContent = cash(data.cost); $("psave").textContent = cash(data.saving);
    $("utilBar").style.width = `${Math.min(100, data.util)}%`;
    $("matchCount").textContent = `${data.matched_count} farmers`;
    $("pooltable").innerHTML = data.farmers.length ? table(`<tr><th>Farmer</th><th>Location</th><th>Quantity</th><th>Ready</th><th>Shared cost</th><th>Est. saving</th></tr>` + data.farmers.map(f=>`<tr><td>${escapeHTML(f.name)}</td><td>${escapeHTML(f.village)}</td><td>${f.qty} qtl</td><td>${escapeHTML(f.ready)}</td><td>${cash(f.share)}</td><td><b>${cash(f.saving)}</b></td></tr>`).join("")) : "<p class='footnote'>No compatible farmers found for this selection.</p>";
    $("poolReason").textContent = `${data.reason} Estimated separate trips: ${cash(data.individual_cost)} · Shared trip: ${cash(data.cost)}.`;
  } catch (error) {$("pooltable").textContent = error.message;}
}
async function markets() {
  try {
    const qty = Math.max(.1, Number($("mqty").value) || 20);
    const pooled = $("mpooled").checked;
    const rows = await api(`/api/mandis?crop=${encodeURIComponent($("mcrop").value)}&quantity=${qty}&pooled=${pooled}`);
    $("marketcards").innerHTML = rows.slice(0,3).map((x,i)=>`<article class="market-card ${i===0?"best":""}"><small>${i===0?"TOP ESTIMATED NET":"MARKET OPTION"}</small><h3>${escapeHTML(x.name)}</h3><strong>${cash(x.net)} <small>/ qtl</small></strong><p>Estimated total for ${qty} qtl: ${cash(x.total)}</p>${i===0?"<span class='best-tag'>BEST NET IN THIS COMPARISON</span>":""}</article>`).join("");
    $("markettable").innerHTML = rows.length ? table(`<tr><th>Market</th><th>Sale price</th><th>Distance</th><th>Transport / qtl</th><th>Loading + fees</th><th>Net / qtl</th></tr>` + rows.map(x=>`<tr><td>${escapeHTML(x.name)}</td><td>${cash(x.price)}</td><td>${x.distance} km</td><td>${cash(x.transport)}</td><td>${cash(x.loading+x.fees)}</td><td><b>${cash(x.net)}</b></td></tr>`).join("")) : "<p class='footnote'>No sample market records for this crop.</p>";
  } catch(error) {$("markettable").textContent = error.message;}
}
async function buyers() {
  try {
    const rows = await api(`/api/buyers?crop=${encodeURIComponent($("bcrop").value)}`);
    $("buyercards").innerHTML = rows.map(x=>`<article class="buyer-card"><small>ILLUSTRATIVE BUYER PROFILE</small><h3>${escapeHTML(x.name)}</h3><p>${escapeHTML(x.location)} · Indicative demand ${x.qty} qtl</p><strong>${cash(x.offer)} <small>/ qtl</small></strong></article>`).join("") || "<p class='footnote'>No demo buyers listed for this crop.</p>";
  } catch(error) {$("buyercards").textContent = error.message;}
}
$("profitForm").addEventListener("submit", async event => {
  event.preventDefault(); const data = Object.fromEntries(new FormData(event.currentTarget));
  Object.keys(data).forEach(key => data[key] = Number(data[key]));
  try {
    const result = await api("/api/profit",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    $("profitResult").innerHTML = `<div class="eyebrow">ESTIMATED NET EARNINGS</div><strong>${cash(result.net)}</strong><p>Revenue: ${cash(result.revenue)} · Estimated expenses: ${cash(result.expenses)} · Net per quintal: ${cash(result.perq)}</p>`;
  } catch(error) {$("profitResult").textContent = error.message;}
});
$("mpooled").addEventListener("change", markets);
$("mcrop").addEventListener("change", markets);
$("bcrop").addEventListener("change", buyers);
$("pcrop").addEventListener("change", pool);
summary().catch(error => {$("cropChart").textContent = error.message;});
