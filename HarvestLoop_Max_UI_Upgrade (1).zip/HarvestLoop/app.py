from __future__ import annotations

import os
import sqlite3
from datetime import date, datetime
from pathlib import Path
from typing import Any

from flask import Flask, jsonify, render_template, request

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB = Path(os.environ.get("HARVESTLOOP_DB", DATA_DIR / "harvestloop.db"))

app = Flask(__name__)
app.config["JSON_SORT_KEYS"] = False


def conn() -> sqlite3.Connection:
    DB.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(str(DB))
    connection.row_factory = sqlite3.Row
    return connection


def init() -> None:
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS farmers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, phone TEXT NOT NULL, village TEXT NOT NULL,
            crop TEXT NOT NULL, qty REAL NOT NULL CHECK(qty > 0), ready TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS mandis(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, crop TEXT NOT NULL, price REAL NOT NULL,
            distance REAL NOT NULL, loading REAL NOT NULL, fees REAL NOT NULL
        );
        CREATE TABLE IF NOT EXISTS buyers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, crop TEXT NOT NULL, qty REAL NOT NULL,
            location TEXT NOT NULL, offer REAL NOT NULL
        );
        """)
        if c.execute("SELECT COUNT(*) FROM farmers").fetchone()[0] == 0:
            c.executemany(
                "INSERT INTO farmers(name,phone,village,crop,qty,ready) VALUES(?,?,?,?,?,?)",
                [
                    ("Ramesh Kumar", "9876501001", "Partapur, Meerut", "Wheat", 20, "2026-12-02"),
                    ("Sunita Devi", "9876501002", "Partapur, Meerut", "Wheat", 15, "2026-12-03"),
                    ("Ajay Singh", "9876501003", "Mohkampur, Meerut", "Wheat", 25, "2026-12-02"),
                    ("Imran Khan", "9876501004", "Partapur, Meerut", "Wheat", 18, "2026-12-04"),
                    ("Pooja", "9876501005", "Modipuram, Meerut", "Sugarcane", 40, "2026-12-05"),
                ],
            )
        if c.execute("SELECT COUNT(*) FROM mandis").fetchone()[0] == 0:
            c.executemany(
                "INSERT INTO mandis(name,crop,price,distance,loading,fees) VALUES(?,?,?,?,?,?)",
                [
                    ("Meerut Mandi", "Wheat", 2425, 18, 55, 25),
                    ("Sardhana Mandi", "Wheat", 2510, 34, 95, 30),
                    ("Hapur Mandi", "Wheat", 2580, 58, 145, 40),
                    ("Modinagar Centre", "Wheat", 2470, 29, 80, 25),
                    ("Meerut Sugar Mill", "Sugarcane", 355, 18, 45, 15),
                    ("Mawana Sugar Mill", "Sugarcane", 365, 31, 75, 20),
                ],
            )
        if c.execute("SELECT COUNT(*) FROM buyers").fetchone()[0] == 0:
            c.executemany(
                "INSERT INTO buyers(name,crop,qty,location,offer) VALUES(?,?,?,?,?)",
                [
                    ("Sharma Grain Traders", "Wheat", 50, "Meerut", 2500),
                    ("Western UP Foods", "Wheat", 100, "Hapur", 2540),
                    ("Kisan Agro Procurement", "Wheat", 30, "Modinagar", 2460),
                    ("Mawana Sugar Buyers", "Sugarcane", 150, "Mawana", 360),
                ],
            )


def _safe_date(value: str) -> date | None:
    try:
        return datetime.strptime(value, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def _place_key(value: str) -> str:
    # Compare the first locality component; this is a simple text heuristic, not GPS.
    return (value or "").split(",")[0].strip().casefold()


def build_pool(rows: list[dict[str, Any]], capacity: float = 70,
               date_window_days: int = 3, anchor_date: str | None = None) -> dict[str, Any]:
    """Greedy, explainable crop/date/capacity grouping; proximity uses locality text only."""
    if capacity <= 0:
        raise ValueError("Vehicle capacity must be greater than zero.")
    if not rows:
        return {"farmers": [], "total": 0, "capacity": capacity, "util": 0,
                "cost": 0, "saving": 0, "perq": 0, "individual_cost": 0,
                "matched_count": 0, "reason": "No farmers are available for this crop."}

    parsed = [(r, _safe_date(str(r.get("ready", "")))) for r in rows]
    valid = [(r, d) for r, d in parsed if d is not None and float(r["qty"]) > 0]
    if anchor_date:
        anchor = _safe_date(anchor_date)
        if anchor is None:
            raise ValueError("Anchor date must use YYYY-MM-DD format.")
        valid = [(r, d) for r, d in valid if abs((d - anchor).days) <= date_window_days]
    if not valid:
        return {"farmers": [], "total": 0, "capacity": capacity, "util": 0,
                "cost": 0, "saving": 0, "perq": 0, "individual_cost": 0,
                "matched_count": 0, "reason": "No farmers have compatible valid harvest dates."}

    valid.sort(key=lambda item: (item[1], _place_key(item[0].get("village", "")), int(item[0]["id"])))
    chosen: list[dict[str, Any]] = []
    total = 0.0
    first_date = valid[0][1]
    first_place = _place_key(valid[0][0].get("village", ""))
    for farmer, ready in valid:
        if total + float(farmer["qty"]) > capacity:
            continue
        if abs((ready - first_date).days) > date_window_days:
            continue
        # Prefer same locality, but allow nearby named localities in the same district
        # because all seeded sample records are within Meerut district.
        farmer_copy = dict(farmer)
        farmer_copy["match_reason"] = (
            "Same crop, compatible harvest window and vehicle capacity; "
            + ("same locality group." if _place_key(farmer.get("village", "")) == first_place
               else "same listed district/region; verify route before dispatch.")
        )
        chosen.append(farmer_copy)
        total += float(farmer["qty"])

    # Demonstration assumptions are clearly disclosed: ₹4,000 per separate trip,
    # ₹7,500 for a shared group trip. Replace with actual quotes in production.
    individual_cost = 4000.0 * len(chosen)
    shared_cost = 7500.0 if chosen else 0.0
    saving = max(0.0, individual_cost - shared_cost)
    for farmer in chosen:
        farmer["share"] = round(shared_cost * float(farmer["qty"]) / total, 2) if total else 0
        farmer["individual_estimate"] = 4000.0
        farmer["saving"] = round(4000.0 - farmer["share"], 2)
    return {
        "farmers": chosen, "total": round(total, 2), "capacity": capacity,
        "util": round(total / capacity * 100, 1) if capacity else 0,
        "cost": shared_cost, "saving": round(saving, 2),
        "individual_cost": individual_cost,
        "perq": round(shared_cost / total, 2) if total else 0,
        "matched_count": len(chosen),
        "reason": "Matched by crop, compatible harvest dates and available vehicle capacity. Location compatibility is a text-based regional hint, not GPS routing.",
    }


@app.get("/")
def home():
    init()
    return render_template("index.html")


@app.get("/api/summary")
def summary():
    init()
    with conn() as c:
        farmers = c.execute("SELECT COUNT(*) FROM farmers").fetchone()[0]
        quantity = c.execute("SELECT COALESCE(SUM(qty),0) FROM farmers").fetchone()[0]
        crops = c.execute("SELECT crop, SUM(qty) AS quantity FROM farmers GROUP BY crop ORDER BY quantity DESC").fetchall()
        mandi_count = c.execute("SELECT COUNT(*) FROM mandis").fetchone()[0]
    return jsonify({"farmers": farmers, "quantity": round(quantity, 2),
                    "mandis": mandi_count, "crops": [dict(x) for x in crops]})


@app.route("/api/farmers", methods=["GET", "POST"])
def farmers():
    init()
    if request.method == "GET":
        with conn() as c:
            return jsonify([dict(x) for x in c.execute("SELECT * FROM farmers ORDER BY id DESC")])
    d = request.get_json(silent=True) or {}
    try:
        qty = float(d.get("quantity", 0))
        name, phone, village, crop, ready = [str(d.get(k, "")).strip()
            for k in ("name", "phone", "village", "crop", "ready_date")]
        if not all([name, phone, village, crop, ready]) or qty <= 0:
            raise ValueError
        if not phone.isdigit() or len(phone) != 10:
            raise ValueError
        if _safe_date(ready) is None:
            raise ValueError
    except (TypeError, ValueError):
        return jsonify(error="Enter a name, valid 10-digit mobile, location, crop, valid date and quantity above zero."), 400
    with conn() as c:
        c.execute("INSERT INTO farmers(name,phone,village,crop,qty,ready) VALUES(?,?,?,?,?,?)",
                  (name, phone, village, crop, qty, ready))
    return jsonify(message="Harvest registered successfully."), 201


@app.get("/api/pooling")
def pooling():
    init()
    crop = request.args.get("crop", "Wheat")
    try:
        capacity = float(request.args.get("capacity", 70))
        window = int(request.args.get("window", 3))
        anchor = request.args.get("anchor") or None
        if capacity <= 0 or window < 0:
            raise ValueError
    except ValueError:
        return jsonify(error="Enter a valid positive vehicle capacity and date window."), 400
    with conn() as c:
        rows = [dict(x) for x in c.execute(
            "SELECT * FROM farmers WHERE crop=? ORDER BY ready,id", (crop,))]
    try:
        return jsonify(build_pool(rows, capacity, window, anchor))
    except ValueError as exc:
        return jsonify(error=str(exc)), 400


@app.get("/api/mandis")
def mandis():
    init()
    crop = request.args.get("crop", "Wheat")
    pooled = request.args.get("pooled", "false").lower() == "true"
    try:
        qty = float(request.args.get("quantity", 20))
        if qty <= 0:
            raise ValueError
    except ValueError:
        return jsonify(error="Quantity must be greater than zero."), 400
    with conn() as c:
        rows = [dict(x) for x in c.execute("SELECT * FROM mandis WHERE crop=?", (crop,))]
    for row in rows:
        row["transport"] = round(row["distance"] * (3 if pooled else 5), 2)
        row["net"] = round(row["price"] - row["transport"] - row["loading"] - row["fees"], 2)
        row["total"] = round(row["net"] * qty, 2)
    return jsonify(sorted(rows, key=lambda x: x["net"], reverse=True))


@app.get("/api/buyers")
def buyers():
    init()
    crop = request.args.get("crop", "Wheat")
    with conn() as c:
        return jsonify([dict(x) for x in c.execute(
            "SELECT * FROM buyers WHERE crop=? ORDER BY offer DESC", (crop,))])


@app.post("/api/profit")
def profit():
    d = request.get_json(silent=True) or {}
    try:
        q, p, t, l, f = [float(d[k]) for k in ("quantity", "price", "transport", "loading", "fees")]
        if q <= 0 or min(p, t, l, f) < 0:
            raise ValueError
    except (KeyError, TypeError, ValueError):
        return jsonify(error="Enter a positive quantity and non-negative price/cost values."), 400
    revenue = q * p
    expenses = q * (t + l + f)
    return jsonify(revenue=round(revenue, 2), expenses=round(expenses, 2),
                   net=round(revenue - expenses, 2), perq=round(p - t - l - f, 2))


@app.get("/health")
def health():
    init()
    return jsonify(status="ok", app="HarvestLoop")


if __name__ == "__main__":
    init()
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", "5000")), debug=False)
